package com.kbmouse.gamepad

import android.content.Context
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

const val MODE_HOLD = 0
const val MODE_TOGGLE = 1
const val MODE_TURBO = 2

const val KIND_TAP = 0
const val KIND_SWIPE = 1

const val MOD_CTRL = 1
const val MOD_SHIFT = 2
const val MOD_ALT = 4

/** Псевдо-коды для кнопок и колеса мыши (у клавиш коды положительные). */
object Mouse {
    const val MIDDLE = -1
    const val BACK = -2
    const val FWD = -3
    const val WHEEL_UP = -4
    const val WHEEL_DOWN = -5
    fun name(code: Int) = when (code) {
        MIDDLE -> "СКМ"
        BACK -> "Бок.назад"
        FWD -> "Бок.вперёд"
        WHEEL_UP -> "Колесо ↑"
        WHEEL_DOWN -> "Колесо ↓"
        else -> "?"
    }
}

fun codeName(code: Int): String =
    if (code < 0) Mouse.name(code) else KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")

fun modsPrefix(m: Int): String {
    var s = ""
    if ((m and MOD_CTRL) != 0) s += "Ctrl+"
    if ((m and MOD_SHIFT) != 0) s += "Shift+"
    if ((m and MOD_ALT) != 0) s += "Alt+"
    return s
}

fun modsOf(e: KeyEvent): Int =
    (if (e.isCtrlPressed) MOD_CTRL else 0) or (if (e.isShiftPressed) MOD_SHIFT else 0) or (if (e.isAltPressed) MOD_ALT else 0)

fun bindLabel(k: KeyBind): String {
    val extra = (when (k.mode) { MODE_TOGGLE -> " ⇄"; MODE_TURBO -> " ⚡"; else -> "" }) + (if (k.kind == KIND_SWIPE) " ↦" else "")
    return modsPrefix(k.mods) + codeName(k.keyCode) + (if (extra.isEmpty()) "" else "\n" + extra.trim())
}

class KeyBind(
    val keyCode: Int, var x: Float, var y: Float, var mode: Int = MODE_HOLD, val mods: Int = 0,
    var kind: Int = KIND_TAP, var ex: Float = -1f, var ey: Float = -1f, var size: Float = 0.11f
)

class Layout(var name: String = "Профиль 1") {
    var pkg = ""
    var joyX = 0.15f; var joyY = 0.68f
    var lookX = 0.72f; var lookY = 0.50f
    var fireX = 0.90f; var fireY = 0.62f
    var aimX = 0.82f; var aimY = 0.42f
    var joySize = 0.28f; var lookSize = 0.56f; var fireSize = 0.14f; var aimSize = 0.14f
    var senX = 1.0f; var senY = 1.0f
    var invertY = false
    var fireTurbo = false
    var aimToggle = false
    val keys = mutableListOf<KeyBind>()

    init { defaultKeys() }

    private fun defaultKeys() {
        keys.clear()
        keys.add(KeyBind(KeyEvent.KEYCODE_SPACE, 0.92f, 0.82f))
        keys.add(KeyBind(KeyEvent.KEYCODE_R, 0.62f, 0.85f))
        keys.add(KeyBind(KeyEvent.KEYCODE_E, 0.55f, 0.70f))
        keys.add(KeyBind(KeyEvent.KEYCODE_F, 0.48f, 0.55f))
        keys.add(KeyBind(KeyEvent.KEYCODE_SHIFT_LEFT, 0.30f, 0.85f))
        keys.add(KeyBind(KeyEvent.KEYCODE_CTRL_LEFT, 0.25f, 0.90f))
    }

    fun resetAll() {
        val d = Layout()
        joyX = d.joyX; joyY = d.joyY; lookX = d.lookX; lookY = d.lookY
        fireX = d.fireX; fireY = d.fireY; aimX = d.aimX; aimY = d.aimY
        joySize = d.joySize; lookSize = d.lookSize; fireSize = d.fireSize; aimSize = d.aimSize
        defaultKeys()
    }

    fun toJson(): String {
        val o = JSONObject()
        o.put("name", name); o.put("pkg", pkg)
        o.put("joyX", joyX.toDouble()); o.put("joyY", joyY.toDouble())
        o.put("lookX", lookX.toDouble()); o.put("lookY", lookY.toDouble())
        o.put("fireX", fireX.toDouble()); o.put("fireY", fireY.toDouble())
        o.put("aimX", aimX.toDouble()); o.put("aimY", aimY.toDouble())
        o.put("senX", senX.toDouble()); o.put("senY", senY.toDouble())
        o.put("joySize", joySize.toDouble()); o.put("lookSize", lookSize.toDouble())
        o.put("fireSize", fireSize.toDouble()); o.put("aimSize", aimSize.toDouble())
        o.put("invY", invertY); o.put("fireTurbo", fireTurbo); o.put("aimToggle", aimToggle)
        val a = JSONArray()
        for (k in keys) {
            a.put(JSONObject().put("c", k.keyCode).put("x", k.x.toDouble()).put("y", k.y.toDouble()).put("m", k.mode).put("d", k.mods).put("k", k.kind).put("ex", k.ex.toDouble()).put("ey", k.ey.toDouble()).put("s", k.size.toDouble()))
        }
        o.put("keys", a)
        return o.toString()
    }

    companion object {
        fun fromJson(s: String): Layout {
            val o = JSONObject(s)
            val l = Layout(o.optString("name", "Профиль"))
            l.pkg = o.optString("pkg", "")
            l.joyX = o.optDouble("joyX", 0.15).toFloat(); l.joyY = o.optDouble("joyY", 0.68).toFloat()
            l.lookX = o.optDouble("lookX", 0.72).toFloat(); l.lookY = o.optDouble("lookY", 0.50).toFloat()
            l.fireX = o.optDouble("fireX", 0.90).toFloat(); l.fireY = o.optDouble("fireY", 0.62).toFloat()
            l.aimX = o.optDouble("aimX", 0.82).toFloat(); l.aimY = o.optDouble("aimY", 0.42).toFloat()
            l.senX = o.optDouble("senX", 1.0).toFloat(); l.senY = o.optDouble("senY", 1.0).toFloat()
            l.joySize = o.optDouble("joySize", 0.28).toFloat(); l.lookSize = o.optDouble("lookSize", 0.56).toFloat()
            l.fireSize = o.optDouble("fireSize", 0.14).toFloat(); l.aimSize = o.optDouble("aimSize", 0.14).toFloat()
            l.invertY = o.optBoolean("invY", false)
            l.fireTurbo = o.optBoolean("fireTurbo", false)
            l.aimToggle = o.optBoolean("aimToggle", false)
            val a = o.optJSONArray("keys")
            if (a != null) {
                l.keys.clear()
                for (i in 0 until a.length()) {
                    val k = a.getJSONObject(i)
                    l.keys.add(KeyBind(k.getInt("c"), k.getDouble("x").toFloat(), k.getDouble("y").toFloat(), k.optInt("m", 0), k.optInt("d", 0),
                        k.optInt("k", 0), k.optDouble("ex", -1.0).toFloat(), k.optDouble("ey", -1.0).toFloat(), k.optDouble("s", 0.11).toFloat()))
                }
            }
            return l
        }
    }
}

/** Общее хранилище профилей (активити и служба живут в одном процессе). */
object Store {
    val profiles = mutableListOf<Layout>()
    var index = 0
    var autoMode = false
    private var loaded = false

    val cur: Layout get() = profiles[index]

    fun init(ctx: Context) {
        if (loaded) return
        loaded = true
        val sp = ctx.getSharedPreferences("store", Context.MODE_PRIVATE)
        try {
            val a = JSONArray(sp.getString("profiles", "[]"))
            for (i in 0 until a.length()) profiles.add(Layout.fromJson(a.getString(i)))
        } catch (e: Exception) { }
        if (profiles.isEmpty()) profiles.add(Layout("Профиль 1"))
        index = sp.getInt("index", 0).coerceIn(0, profiles.size - 1)
        autoMode = sp.getBoolean("auto", false)
    }

    fun save(ctx: Context) {
        val a = JSONArray()
        for (p in profiles) a.put(p.toJson())
        ctx.getSharedPreferences("store", Context.MODE_PRIVATE).edit()
            .putString("profiles", a.toString()).putInt("index", index).putBoolean("auto", autoMode).apply()
    }
}
