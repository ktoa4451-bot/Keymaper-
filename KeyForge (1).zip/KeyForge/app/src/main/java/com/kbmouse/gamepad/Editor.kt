package com.kbmouse.gamepad

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.hypot

class LinesView(ctx: Context, private val draw: (Canvas) -> Unit) : View(ctx) {
    override fun onDraw(canvas: Canvas) {
        draw(canvas)
    }
}

/** Оверлей поверх игры: перетаскивай кружки, меняй размер, добавляй кнопки и свайпы. */
class Editor(
    private val svc: MapperService,
    private val wm: WindowManager,
    private val layout: Layout,
    private val size: Pair<Int, Int>,
    private val onClosed: () -> Unit
) {
    private val ctx: Context = svc
    private val dp = ctx.resources.displayMetrics.density
    private val minPx = (44 * dp).toInt()
    private val root = FrameLayout(ctx)
    private val hint = TextView(ctx)
    private val bar2 = LinearLayout(ctx)
    private val seekLabel = TextView(ctx)
    private val seek = SeekBar(ctx)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private class M(
        val v: TextView,
        val onPlace: (Float, Float) -> Unit,
        val onSize: ((Float) -> Unit)?,
        var sz: Float,
        val key: KeyBind?,
        val isEnd: Boolean,
        var px: Int
    ) {
        var partner: M? = null
    }

    private val ms = mutableListOf<M>()
    private var sel: M? = null
    private var waiting = false
    private var waitSwipe = false
    private var deleting = false
    private var pendCode = 0
    private val modeNames = arrayOf("удержание", "переключатель", "авто-нажатие")
    private val orange = Color.parseColor("#EF6C00")
    private val teal = Color.parseColor("#00897B")

    private fun pxOf(frac: Float) = maxOf((frac * size.second).toInt(), minPx)

    init {
        linePaint.color = Color.WHITE
        linePaint.strokeWidth = 3 * dp
        linePaint.alpha = 200
        root.setBackgroundColor(0x99000000.toInt())
        root.addView(LinesView(ctx) { c ->
            for (m in ms) {
                val p = m.partner
                if (!m.isEnd && p != null) {
                    c.drawLine(m.v.x + m.px / 2f, m.v.y + m.px / 2f, p.v.x + p.px / 2f, p.v.y + p.px / 2f, linePaint)
                }
            }
        }, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        addMarker("Джойстик\nWASD", Color.parseColor("#2E7D32"), layout.joyX, layout.joyY, layout.joySize, null, false,
            { x, y -> layout.joyX = x; layout.joyY = y }, { s -> layout.joySize = s })
        addMarker("Камера\n(мышь)", Color.parseColor("#1565C0"), layout.lookX, layout.lookY, layout.lookSize, null, false,
            { x, y -> layout.lookX = x; layout.lookY = y }, { s -> layout.lookSize = s })
        addMarker("Огонь\nЛКМ", Color.parseColor("#C62828"), layout.fireX, layout.fireY, layout.fireSize, null, false,
            { x, y -> layout.fireX = x; layout.fireY = y }, { s -> layout.fireSize = s })
        addMarker("Прицел\nПКМ", Color.parseColor("#6A1B9A"), layout.aimX, layout.aimY, layout.aimSize, null, false,
            { x, y -> layout.aimX = x; layout.aimY = y }, { s -> layout.aimSize = s })
        for (k in layout.keys) addKeyMarker(k)

        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.VERTICAL

        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER
        bar.setBackgroundColor(0xCC222222.toInt())
        bar.addView(btn("Готово") { close(true) })
        bar.addView(btn("+ Кнопка") {
            waiting = true; waitSwipe = false; pendCode = 0
            hint.text = "Нажми клавишу (или Ctrl/Shift/Alt + клавишу для комбо)…"
        })
        bar.addView(btn("+ Свайп") {
            waiting = true; waitSwipe = true; pendCode = 0
            hint.text = "Нажми клавишу для свайпа, потом перетащи начало и конец (→)"
        })
        bar.addView(btn("+ Мышь") { bar2.visibility = if (bar2.visibility == View.VISIBLE) View.GONE else View.VISIBLE })
        bar.addView(btn("Удалить: выкл") { b ->
            deleting = !deleting
            b.text = if (deleting) "Удалить: ВКЛ" else "Удалить: выкл"
            hint.text = if (deleting) "Тапни по кружку, чтобы удалить кнопку" else ""
        })
        bar.addView(btn("Сброс") { layout.resetAll(); close(false); svc.startEditor() })
        top.addView(bar)

        bar2.orientation = LinearLayout.HORIZONTAL
        bar2.gravity = Gravity.CENTER
        bar2.setBackgroundColor(0xCC333333.toInt())
        bar2.visibility = View.GONE
        for (c in intArrayOf(Mouse.WHEEL_UP, Mouse.WHEEL_DOWN, Mouse.MIDDLE, Mouse.BACK, Mouse.FWD)) {
            bar2.addView(btn(Mouse.name(c)) { addBind(c, 0, false) })
        }
        top.addView(bar2)

        val bar3 = LinearLayout(ctx)
        bar3.orientation = LinearLayout.HORIZONTAL
        bar3.gravity = Gravity.CENTER_VERTICAL
        bar3.setBackgroundColor(0xCC222222.toInt())
        bar3.setPadding((8 * dp).toInt(), 0, (8 * dp).toInt(), 0)
        seekLabel.setTextColor(Color.WHITE)
        seekLabel.textSize = 12f
        seekLabel.text = "Тапни кружок — появится размер"
        bar3.addView(seekLabel)
        seek.max = 100
        seek.isEnabled = false
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val m = sel ?: return
                val s = 0.06f + p * 0.0064f
                m.sz = s
                m.onSize?.invoke(s)
                resize(m)
                seekLabel.text = "Размер: " + (s * 100).toInt()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        bar3.addView(seek, LinearLayout.LayoutParams((240 * dp).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT))
        top.addView(bar3)

        root.addView(top, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        hint.setTextColor(Color.WHITE)
        hint.textSize = 13f
        hint.text = "Перетаскивай кружки. Долгое нажатие на кнопку — режим (удержание / переключатель / авто)"
        val hp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        hp.topMargin = (150 * dp).toInt()
        root.addView(hint, hp)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(root, lp)
    }

    private fun btn(text: String, click: (Button) -> Unit): Button {
        val b = Button(ctx)
        b.text = text
        b.textSize = 10f
        b.setOnClickListener { click(b) }
        return b
    }

    private fun setStroke(m: M, on: Boolean) {
        val bg = m.v.background as GradientDrawable
        bg.setStroke(((if (on) 4 else 2) * dp).toInt(), if (on) Color.YELLOW else Color.WHITE)
    }

    private fun select(m: M?) {
        sel?.let { setStroke(it, false) }
        sel = m
        if (m == null) return
        setStroke(m, true)
        if (m.onSize != null) {
            seek.isEnabled = true
            seek.progress = ((m.sz - 0.06f) / 0.64f * 100).toInt().coerceIn(0, 100)
            seekLabel.text = "Размер: " + (m.sz * 100).toInt()
        } else {
            seek.isEnabled = false
            seekLabel.text = "Размер: —"
        }
    }

    private fun resize(m: M) {
        val old = m.px
        val np = pxOf(m.sz)
        val cx = m.v.x + old / 2f
        val cy = m.v.y + old / 2f
        val lp = m.v.layoutParams
        lp.width = np
        lp.height = np
        m.v.layoutParams = lp
        m.v.x = cx - np / 2f
        m.v.y = cy - np / 2f
        m.px = np
    }

    private fun addKeyMarker(k: KeyBind): M {
        val a = addMarker(bindLabel(k), orange, k.x, k.y, k.size, k, false,
            { x, y -> k.x = x; k.y = y }, { s -> k.size = s })
        if (k.kind == KIND_SWIPE) {
            val b = addMarker("→", teal, k.ex, k.ey, 0.07f, k, true, { x, y -> k.ex = x; k.ey = y }, null)
            a.partner = b
            b.partner = a
        }
        return a
    }

    private fun addMarker(
        label: String, color: Int, fx: Float, fy: Float, sz: Float, key: KeyBind?, isEnd: Boolean,
        onPlace: (Float, Float) -> Unit, onSize: ((Float) -> Unit)?
    ): M {
        val px = pxOf(sz)
        val tv = TextView(ctx)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 11f
        tv.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(color and 0x00FFFFFF or 0xB0000000.toInt())
        bg.setStroke((2 * dp).toInt(), Color.WHITE)
        tv.background = bg
        root.addView(tv, FrameLayout.LayoutParams(px, px))
        tv.x = fx * size.first - px / 2f
        tv.y = fy * size.second - px / 2f
        val m = M(tv, onPlace, onSize, sz, key, isEnd, px)
        ms.add(m)

        var dX = 0f
        var dY = 0f
        var sX = 0f
        var sY = 0f
        var moved = false
        var longDone = false
        val longRun = Runnable {
            if (key != null && !moved) {
                key.mode = (key.mode + 1) % 3
                val start = if (isEnd) m.partner else m
                start?.v?.text = bindLabel(key)
                hint.text = "Режим: " + modeNames[key.mode]
                longDone = true
            }
        }
        tv.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dX = v.x - ev.rawX; dY = v.y - ev.rawY
                    sX = ev.rawX; sY = ev.rawY
                    moved = false; longDone = false
                    select(m)
                    root.postDelayed(longRun, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && hypot(ev.rawX - sX, ev.rawY - sY) > 12 * dp) { moved = true; root.removeCallbacks(longRun) }
                    if (moved) {
                        v.x = ev.rawX + dX
                        v.y = ev.rawY + dY
                        root.invalidate()
                        root.getChildAt(0).invalidate()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    root.removeCallbacks(longRun)
                    if (ev.actionMasked == MotionEvent.ACTION_UP && !moved && !longDone && deleting && key != null) {
                        layout.keys.remove(key)
                        val p = m.partner
                        for (x in listOfNotNull(m, p)) { ms.remove(x); root.removeView(x.v) }
                        sel = null
                        root.getChildAt(0).invalidate()
                    }
                }
            }
            true
        }
        return m
    }

    private fun addBind(code: Int, mods: Int, swipe: Boolean) {
        val reserved = (mods == 0 && (code == KeyEvent.KEYCODE_W || code == KeyEvent.KEYCODE_A ||
            code == KeyEvent.KEYCODE_S || code == KeyEvent.KEYCODE_D)) ||
            code == MapperService.KEY_TOGGLE || code == MapperService.KEY_FREE
        if (reserved || layout.keys.any { it.keyCode == code && it.mods == mods }) {
            hint.text = "Эта клавиша занята, выбери другую"
            return
        }
        val k = if (swipe) KeyBind(code, 0.40f, 0.50f, MODE_HOLD, mods, KIND_SWIPE, 0.60f, 0.50f)
        else KeyBind(code, 0.5f, 0.5f, MODE_HOLD, mods)
        layout.keys.add(k)
        val m = addKeyMarker(k)
        select(m)
        waiting = false
        pendCode = 0
        root.getChildAt(0).invalidate()
        hint.text = if (swipe) "Свайп добавлен: перетащи начало и конец (→)" else "Добавлено — перетащи кружок на нужное место"
    }

    private fun isModKey(c: Int) = c == KeyEvent.KEYCODE_CTRL_LEFT || c == KeyEvent.KEYCODE_CTRL_RIGHT ||
        c == KeyEvent.KEYCODE_SHIFT_LEFT || c == KeyEvent.KEYCODE_SHIFT_RIGHT ||
        c == KeyEvent.KEYCODE_ALT_LEFT || c == KeyEvent.KEYCODE_ALT_RIGHT

    fun onKey(e: KeyEvent): Boolean {
        if (!waiting) return false
        val c = e.keyCode
        val mod = isModKey(c)
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
            if (mod) {
                pendCode = c
                hint.text = "Нажми вторую клавишу для комбо или отпусти эту, чтобы добавить её саму"
            } else {
                addBind(c, modsOf(e), waitSwipe)
            }
        } else if (e.action == KeyEvent.ACTION_UP && mod && c == pendCode) {
            addBind(c, 0, waitSwipe)
        }
        return true
    }

    fun close(save: Boolean) {
        if (save) {
            for (m in ms) m.onPlace((m.v.x + m.px / 2f) / size.first, (m.v.y + m.px / 2f) / size.second)
        }
        try { wm.removeView(root) } catch (e: Exception) { }
        onClosed()
    }
}
