package com.kbmouse.gamepad

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var dp = 1f

    private val cBg = 0xFF0E1116.toInt()
    private val cCard = 0xFF1A1E27.toInt()
    private val cAccent = 0xFF4F8CFF.toInt()
    private val cBtn = 0xFF2A3040.toInt()
    private val cText = 0xFFE8EAF0.toInt()
    private val cSub = 0xFF9AA3B2.toInt()

    private fun dpi(v: Int) = (v * dp).toInt()

    private fun round(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = r * dp
        return g
    }

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = round(cCard, 16)
        c.setPadding(dpi(16), dpi(14), dpi(16), dpi(16))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dpi(12)
        parent.addView(c, lp)
        c.addView(tv(title, 16f, cText, true))
        return c
    }

    private fun mkBtn(label: String, primary: Boolean, click: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 14f
        b.background = round(if (primary) cAccent else cBtn, 12)
        b.setOnClickListener { click() }
        return b
    }

    private fun btn(parent: LinearLayout, label: String, primary: Boolean, click: () -> Unit) {
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpi(48))
        lp.topMargin = dpi(8)
        parent.addView(mkBtn(label, primary, click), lp)
    }

    private fun row(parent: LinearLayout, items: List<Pair<String, () -> Unit>>) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for ((label, click) in items) {
            val lp = LinearLayout.LayoutParams(0, dpi(46), 1f)
            lp.setMargins(dpi(3), dpi(8), dpi(3), 0)
            r.addView(mkBtn(label, false, click), lp)
        }
        parent.addView(r)
    }

    private fun sw(parent: LinearLayout, label: String, init: Boolean, set: (Boolean) -> Unit) {
        val s = Switch(this)
        s.text = label
        s.setTextColor(cText)
        s.textSize = 14f
        s.isChecked = init
        s.setPadding(0, dpi(10), 0, dpi(6))
        s.setOnCheckedChangeListener { _, v -> set(v); Store.save(this) }
        parent.addView(s)
    }

    private fun fmt(v: Float) = String.format("%.1f", v)

    private fun seek(parent: LinearLayout, label: String, cur: Float, set: (Float) -> Unit) {
        val t = tv(label + ": " + fmt(cur), 14f, cText)
        t.setPadding(0, dpi(10), 0, 0)
        parent.addView(t)
        val sb = SeekBar(this)
        sb.max = 27
        sb.progress = ((cur - 0.3f) / 0.1f).toInt().coerceIn(0, 27)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = 0.3f + p * 0.1f
                set(v)
                t.text = label + ": " + fmt(v)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) { Store.save(this@MainActivity) }
        })
        parent.addView(sb)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        dp = resources.displayMetrics.density
        window.statusBarColor = cBg
        val l = Store.cur

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dpi(16), dpi(20), dpi(16), dpi(24))

        // шапка
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_launcher_foreground)
        val lg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF4F8CFF.toInt(), 0xFF7B4DFF.toInt()))
        lg.cornerRadius = 16 * dp
        logo.background = lg
        head.addView(logo, LinearLayout.LayoutParams(dpi(64), dpi(64)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dpi(14), 0, 0, 0)
        titles.addView(tv("KeyForge", 26f, cText, true))
        titles.addView(tv("Клавиатура, мышь и геймпад для мобильных игр", 13f, cSub))
        head.addView(titles)
        col.addView(head)

        status = tv("", 13f, Color.WHITE, true)
        status.setPadding(dpi(12), dpi(6), dpi(12), dpi(6))
        val slp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dpi(14)
        col.addView(status, slp)

        // запуск
        val c1 = card(col, "Запуск")
        btn(c1, "1. Включить службу KeyForge", false) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn(c1, "2. Расставить кнопки поверх игры", false) {
            val s = MapperService.instance
            if (s == null) toast("Сначала включи службу KeyForge") else { s.startEditor(); moveTaskToBack(true) }
        }
        btn(c1, "Режим игры: вкл / выкл", true) {
            val s = MapperService.instance
            if (s == null) toast("Сначала включи службу KeyForge") else s.setActive(!s.active)
        }

        // профиль
        val c2 = card(col, "Профиль: " + l.name)
        c2.addView(tv("Привязка к игре: " + (if (l.pkg.isEmpty()) "нет" else l.pkg), 13f, cSub))
        row(c2, listOf<Pair<String, () -> Unit>>(
            "Выбрать" to {
                AlertDialog.Builder(this).setTitle("Профиль")
                    .setItems(Store.profiles.map { it.name }.toTypedArray()) { _, i ->
                        Store.index = i; Store.save(this); recreate()
                    }.show()
                Unit
            },
            "Новый" to {
                val et = EditText(this)
                et.setText("Профиль " + (Store.profiles.size + 1))
                AlertDialog.Builder(this).setTitle("Название").setView(et)
                    .setPositiveButton("Создать") { _, _ ->
                        Store.profiles.add(Layout(et.text.toString().ifBlank { "Профиль" }))
                        Store.index = Store.profiles.size - 1
                        Store.save(this); recreate()
                    }.setNegativeButton("Отмена", null).show()
                Unit
            },
            "Удалить" to {
                if (Store.profiles.size > 1) {
                    Store.profiles.removeAt(Store.index); Store.index = 0; Store.save(this); recreate()
                } else toast("Нельзя удалить единственный профиль")
            }
        ))
        row(c2, listOf<Pair<String, () -> Unit>>(
            "Привязать к последней игре" to {
                val p = MapperService.instance?.lastPkg
                if (p == null) toast("Включи службу, открой игру и вернись сюда")
                else { Store.cur.pkg = p; Store.save(this); recreate() }
            },
            "Отвязать" to { Store.cur.pkg = ""; Store.save(this); recreate() }
        ))
        sw(c2, "Автовключение в привязанных играх", Store.autoMode) { Store.autoMode = it }

        // мышь и камера
        val c3 = card(col, "Мышь и камера")
        sw(c3, "ЛКМ — автострельба", l.fireTurbo) { l.fireTurbo = it }
        sw(c3, "ПКМ — переключатель прицела", l.aimToggle) { l.aimToggle = it }
        sw(c3, "Инвертировать ось Y", l.invertY) { l.invertY = it }
        seek(c3, "Чувствительность X", l.senX) { l.senX = it }
        seek(c3, "Чувствительность Y", l.senY) { l.senY = it }

        // подсказка
        val c4 = card(col, "Как пользоваться")
        c4.addView(tv("F8 — включить или выключить режим игры\nF9 — свободный курсор (для меню игры)\n\nВ редакторе: тап по кружку — выбрать и менять размер, перетаскивание — переместить, долгое нажатие — режим кнопки (удержание / переключатель / авто), «+ Кнопка» — своя клавиша или комбо, «+ Свайп» — клавиша проводит пальцем от начала до конца (→), «+ Мышь» — колесо и боковые кнопки.", 13f, cSub))

        val sv = ScrollView(this)
        sv.setBackgroundColor(cBg)
        sv.addView(col)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        val on = MapperService.instance != null
        status.text = if (on) "● Служба включена" else "● Служба выключена"
        status.background = round(if (on) 0xFF1E5E3A.toInt() else 0xFF5E2A2A.toInt(), 20)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
