# KeyForge
Клавиатура, мышь и геймпад -> касания экрана для мобильных игр.

## Сборка APK из ZIP (с телефона)
1. Создай репозиторий на GitHub.
2. Залей в корень репозитория сам файл KeyForge.zip (Add file -> Upload files) — распаковывать не надо.
3. Add file -> Create new file, имя файла: .github/workflows/build.yml — вставь содержимое build.yml из архива.
4. Вкладка Actions -> Build APK from ZIP -> дождись зелёной галочки -> Artifacts -> KeyForge-apk (внутри APK).
