package com.kbmouse.gamepad

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import kotlin.math.hypot

class MapperService : AccessibilityService() {
    companion object {
        @Volatile var instance: MapperService? = null
        const val KEY_TOGGLE = KeyEvent.KEYCODE_F8
        const val KEY_FREE = KeyEvent.KEYCODE_F9
    }

    private val layout: Layout get() = Store.cur
    private lateinit var engine: TouchEngine
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    @Volatile var lastPkg: String? = null
    var active = false
        private set
    var free = false
        private set
    private var mouseView: MouseView? = null
    private var editor: Editor? = null

    private var counter = 0
    private val held = HashMap<String, String>()        // тег -> id касания
    private val turbo = HashMap<String, Runnable>()
    private val pressed = HashMap<Int, KeyBind>()
    private val dirs = BooleanArray(4)                   // W A S D
    private var stickX = 0f
    private var stickY = 0f
    private var joyId: String? = null
    private var lookId: String? = null
    private var lookX = 0f
    private var lookY = 0f
    private val lookIdle = Runnable { endLook() }
    private var rsX = 0f
    private var rsY = 0f
    private var stickRunning = false
    private val stickLoop = object : Runnable {
        override fun run() {
            if (!active || free || (rsX == 0f && rsY == 0f)) { stickRunning = false; return }
            onMouseMove(rsX * 14f, rsY * 14f)
            handler.postDelayed(this, 16)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Store.init(this)
        engine = TouchEngine(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    private fun ignored(p: String) = p == packageName || p == "com.android.systemui" || p == "android" ||
        p.contains("inputmethod") || p.contains("keyboard") || p.contains(".ime")

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = event.packageName?.toString() ?: return
        if (ignored(p)) return
        lastPkg = p
        if (!Store.autoMode || editor != null) return
        val i = Store.profiles.indexOfFirst { it.pkg == p }
        if (i >= 0) {
            if (Store.index != i) { Store.index = i; Store.save(this) }
            if (!active) setActive(true)
        } else if (active) {
            setActive(false)
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        setActive(false)
        editor?.close(false)
        instance = null
        return super.onUnbind(intent)
    }

    fun screen(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun newId(p: String) = p + (counter++)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun setActive(on: Boolean) {
        if (on == active) return
        if (on && editor != null) return
        active = on
        if (on) {
            free = false
            val v = MouseView(this, this)
            val lp = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            mouseView = v
            toast("Режим игры: ВКЛ — " + layout.name + " (F8 выкл, F9 свободный курсор)")
        } else {
            free = false
            mouseView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
            mouseView = null
            releaseAll()
            toast("Режим игры: ВЫКЛ")
        }
    }

    fun setFree(f: Boolean) {
        if (!active || f == free) return
        free = f
        if (f) { endLook(); releaseTag("fire"); releaseTag("aim") }
        mouseView?.setFree(f)
        toast(if (f) "Курсор свободен (F9 — вернуть захват)" else "Мышь захвачена")
    }

    fun startEditor() {
        if (editor != null) return
        setActive(false)
        editor = Editor(this, wm, Store.cur, screen()) {
            editor = null
            Store.save(this)
        }
    }

    private fun releaseAll() {
        handler.removeCallbacks(lookIdle)
        for (r in turbo.values) handler.removeCallbacks(r)
        turbo.clear()
        engine.clear()
        held.clear(); pressed.clear()
        joyId = null; lookId = null
        for (i in dirs.indices) dirs[i] = false
        stickX = 0f; stickY = 0f; rsX = 0f; rsY = 0f
    }

    // ---- касания по тегам ----
    private fun downTouch(tag: String, x: Float, y: Float) {
        if (held.containsKey(tag)) return
        val id = newId("t")
        held[tag] = id
        engine.down(id, x, y)
    }

    private fun releaseTouch(tag: String) {
        held.remove(tag)?.let { engine.up(it) }
    }

    private fun stopTurbo(tag: String) {
        turbo.remove(tag)?.let { handler.removeCallbacks(it) }
    }

    private fun releaseTag(tag: String) {
        stopTurbo(tag)
        releaseTouch(tag)
    }

    private fun press(tag: String, fx: Float, fy: Float, mode: Int) {
        val (w, h) = screen()
        val x = fx * w
        val y = fy * h
        when (mode) {
            MODE_TOGGLE -> if (held.containsKey(tag)) releaseTouch(tag) else downTouch(tag, x, y)
            MODE_TURBO -> {
                if (turbo.containsKey(tag)) return
                val r = object : Runnable {
                    override fun run() {
                        downTouch(tag, x, y)
                        handler.postDelayed({ releaseTouch(tag) }, 40)
                        handler.postDelayed(this, 90)
                    }
                }
                turbo[tag] = r
                r.run()
            }
            else -> downTouch(tag, x, y)
        }
    }

    private fun release(tag: String, mode: Int) {
        when (mode) {
            MODE_TOGGLE -> {}
            MODE_TURBO -> stopTurbo(tag)
            else -> releaseTouch(tag)
        }
    }

    private fun pulse(tag: String, fx: Float, fy: Float) {
        val (w, h) = screen()
        downTouch(tag, fx * w, fy * h)
        handler.postDelayed({ releaseTouch(tag) }, 50)
    }

    private fun onBind(kb: KeyBind, down: Boolean) {
        val tag = "b" + kb.keyCode + ":" + kb.mods
        if (kb.keyCode == Mouse.WHEEL_UP || kb.keyCode == Mouse.WHEEL_DOWN) {
            if (down) pulse(tag, kb.x, kb.y)
            return
        }
        if (down) press(tag, kb.x, kb.y, kb.mode) else release(tag, kb.mode)
    }

    // ---- клавиатура / геймпад (кнопки) ----
    override fun onKeyEvent(e: KeyEvent): Boolean {
        val down = e.action == KeyEvent.ACTION_DOWN
        val code = e.keyCode
        editor?.let { return it.onKey(e) }
        if (code == KEY_TOGGLE) {
            if (down && e.repeatCount == 0) setActive(!active)
            return true
        }
        if (!active) return false
        if (code == KEY_FREE) {
            if (down && e.repeatCount == 0) setFree(!free)
            return true
        }
        val dir = when (code) {
            KeyEvent.KEYCODE_W -> 0
            KeyEvent.KEYCODE_A -> 1
            KeyEvent.KEYCODE_S -> 2
            KeyEvent.KEYCODE_D -> 3
            else -> -1
        }
        if (dir >= 0) {
            if (e.repeatCount == 0) { dirs[dir] = down; updateJoystick() }
            return true
        }
        if (down) {
            if (e.repeatCount > 0) return pressed.containsKey(code)
            val mods = modsOf(e)
            val kb = layout.keys.firstOrNull { it.keyCode == code && it.mods == mods }
                ?: layout.keys.firstOrNull { it.keyCode == code && it.mods == 0 }
                ?: return false
            pressed[code] = kb
            onBind(kb, true)
            return true
        }
        val kb = pressed.remove(code) ?: return false
        onBind(kb, false)
        return true
    }

    // ---- джойстик (WASD или левый стик) ----
    fun onLeftStick(x: Float, y: Float) {
        stickX = x; stickY = y
        if (active) updateJoystick()
    }

    private fun updateJoystick() {
        var dx = 0f
        var dy = 0f
        if (dirs[0]) dy -= 1f
        if (dirs[2]) dy += 1f
        if (dirs[1]) dx -= 1f
        if (dirs[3]) dx += 1f
        if (dx == 0f && dy == 0f) { dx = stickX; dy = stickY }
        val len = hypot(dx, dy)
        val id = joyId
        if (len < 0.01f) {
            if (id != null) { engine.up(id); joyId = null }
            return
        }
        val (w, h) = screen()
        val m = if (len > 1f) 1f / len else 1f
        val r = 0.14f * h
        val cx = layout.joyX * w
        val cy = layout.joyY * h
        val tx = cx + dx * m * r
        val ty = cy + dy * m * r
        if (id == null) {
            val n = newId("joy")
            joyId = n
            engine.down(n, cx, cy)
            engine.move(n, tx, ty)
        } else {
            engine.move(id, tx, ty)
        }
    }

    // ---- камера (мышь или правый стик) ----
    fun onRightStick(x: Float, y: Float) {
        rsX = x; rsY = y
        if (!stickRunning && (x != 0f || y != 0f)) { stickRunning = true; handler.post(stickLoop) }
    }

    fun onMouseMove(dx: Float, dy: Float) {
        if (!active || free) return
        val (w, h) = screen()
        val cx = layout.lookX * w
        val cy = layout.lookY * h
        var id = lookId
        if (id == null) {
            id = newId("look")
            lookId = id
            lookX = cx; lookY = cy
            engine.down(id, cx, cy)
        }
        lookX += dx * layout.senX * 1.5f
        lookY += dy * layout.senY * 1.5f * (if (layout.invertY) -1f else 1f)
        val r = 0.28f * h
        val ox = lookX - cx
        val oy = lookY - cy
        val d = hypot(ox, oy)
        if (d > r) {
            lookX = cx + ox / d * r
            lookY = cy + oy / d * r
            engine.move(id, lookX, lookY)
            endLook()
            return
        }
        engine.move(id, lookX, lookY)
        handler.removeCallbacks(lookIdle)
        handler.postDelayed(lookIdle, 120)
    }

    private fun endLook() {
        handler.removeCallbacks(lookIdle)
        lookId?.let { engine.up(it) }
        lookId = null
    }

    // ---- кнопки мыши / триггеры ----
    fun onFire(down: Boolean) {
        if (!active || free) return
        val mode = if (layout.fireTurbo) MODE_TURBO else MODE_HOLD
        if (down) press("fire", layout.fireX, layout.fireY, mode) else release("fire", mode)
    }

    fun onAim(down: Boolean) {
        if (!active || free) return
        val mode = if (layout.aimToggle) MODE_TOGGLE else MODE_HOLD
        if (down) press("aim", layout.aimX, layout.aimY, mode) else release("aim", mode)
    }

    fun onExtra(code: Int, down: Boolean) {
        if (!active || free) return
        layout.keys.firstOrNull { it.keyCode == code }?.let { onBind(it, down) }
    }
}
