package com.kbmouse.gamepad

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        val l = Store.cur
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        fun text(s: String, size: Float = 15f): TextView {
            val t = TextView(this)
            t.text = s; t.textSize = size
            t.setPadding(0, pad / 2, 0, pad / 2)
            col.addView(t)
            return t
        }
        fun button(s: String, click: () -> Unit) {
            val b = Button(this)
            b.text = s
            b.setOnClickListener { click() }
            col.addView(b)
        }
        fun check(label: String, init: Boolean, set: (Boolean) -> Unit) {
            val c = CheckBox(this)
            c.text = label
            c.isChecked = init
            c.setOnCheckedChangeListener { _, v -> set(v); Store.save(this) }
            col.addView(c)
        }
        fun seek(label: String, cur: Float, set: (Float) -> Unit) {
            text(label)
            val sb = SeekBar(this)
            sb.max = 27
            sb.progress = ((cur - 0.3f) / 0.1f).toInt().coerceIn(0, 27)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) set(0.3f + p * 0.1f)
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) { Store.save(this@MainActivity) }
            })
            col.addView(sb)
        }

        text("KeyMapper", 24f)
        status = text("")
        text("1) Включи службу KeyMapper в спец. возможностях.\n2) «Редактировать раскладку» — расставь кружки поверх кнопок игры.\n3) В игре жми F8 — режим игры вкл/выкл, F9 — свободный курсор (для меню).\n\nWASD или левый стик — джойстик, мышь или правый стик — камера, ЛКМ/ПКМ или триггеры — огонь/прицел, колесо и боковые кнопки мыши, любые клавиши, комбо (Ctrl+1) и кнопки геймпада — по твоей раскладке.")

        button("Открыть настройки спец. возможностей") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("Редактировать раскладку (поверх игры)") {
            val s = MapperService.instance
            if (s == null) toast("Сначала включи службу KeyMapper") else { s.startEditor(); moveTaskToBack(true) }
        }
        button("Режим игры вкл/выкл") {
            val s = MapperService.instance
            if (s == null) toast("Сначала включи службу KeyMapper") else s.setActive(!s.active)
        }

        text("Профиль: " + l.name + "\nПривязка к игре: " + (if (l.pkg.isEmpty()) "нет" else l.pkg), 16f)
        button("Выбрать профиль") {
            AlertDialog.Builder(this).setTitle("Профиль")
                .setItems(Store.profiles.map { it.name }.toTypedArray()) { _, i ->
                    Store.index = i; Store.save(this); recreate()
                }.show()
        }
        button("Новый профиль") {
            val et = EditText(this)
            et.setText("Профиль " + (Store.profiles.size + 1))
            AlertDialog.Builder(this).setTitle("Название").setView(et)
                .setPositiveButton("Создать") { _, _ ->
                    Store.profiles.add(Layout(et.text.toString().ifBlank { "Профиль" }))
                    Store.index = Store.profiles.size - 1
                    Store.save(this); recreate()
                }.setNegativeButton("Отмена", null).show()
        }
        button("Удалить профиль") {
            if (Store.profiles.size > 1) {
                Store.profiles.removeAt(Store.index); Store.index = 0; Store.save(this); recreate()
            } else toast("Нельзя удалить единственный профиль")
        }
        button("Привязать к последней открытой игре") {
            val p = MapperService.instance?.lastPkg
            if (p == null) toast("Включи службу, открой игру и вернись сюда")
            else { Store.cur.pkg = p; Store.save(this); recreate() }
        }
        button("Отвязать от игры") { Store.cur.pkg = ""; Store.save(this); recreate() }

        check("Автовключение в привязанных играх", Store.autoMode) { Store.autoMode = it }
        check("ЛКМ — автострельба (зажатие = серия тапов)", l.fireTurbo) { l.fireTurbo = it }
        check("ПКМ — переключатель (нажал — прицел, ещё раз — выкл)", l.aimToggle) { l.aimToggle = it }
        check("Инвертировать ось Y камеры", l.invertY) { l.invertY = it }
        seek("Чувствительность камеры по X", l.senX) { l.senX = it }
        seek("Чувствительность камеры по Y", l.senY) { l.senY = it }

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (MapperService.instance != null) "Служба: включена ✅" else "Служба: выключена ❌"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
