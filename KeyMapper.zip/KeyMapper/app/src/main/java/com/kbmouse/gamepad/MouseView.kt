package com.kbmouse.gamepad

import android.content.Context
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/** Крошечное окно в фокусе: захват мыши (pointer capture) + оси геймпада. */
class MouseView(ctx: Context, private val svc: MapperService) : View(ctx) {
    private var prev = 0
    private var free = false
    private var rt = false
    private var lt = false

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    fun setFree(f: Boolean) {
        free = f
        if (f) releasePointerCapture() else requestPointerCapture()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        requestFocus()
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus && !free) requestPointerCapture()
    }

    override fun onCapturedPointerEvent(e: MotionEvent): Boolean {
        val now = e.buttonState
        val ch = now xor prev
        fun chk(bit: Int, f: (Boolean) -> Unit) {
            if ((ch and bit) != 0) f((now and bit) != 0)
        }
        chk(MotionEvent.BUTTON_PRIMARY) { svc.onFire(it) }
        chk(MotionEvent.BUTTON_SECONDARY) { svc.onAim(it) }
        chk(MotionEvent.BUTTON_TERTIARY) { svc.onExtra(Mouse.MIDDLE, it) }
        chk(MotionEvent.BUTTON_BACK) { svc.onExtra(Mouse.BACK, it) }
        chk(MotionEvent.BUTTON_FORWARD) { svc.onExtra(Mouse.FWD, it) }
        prev = now
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_HOVER_MOVE -> svc.onMouseMove(e.x, e.y)
            MotionEvent.ACTION_SCROLL -> {
                val v = e.getAxisValue(MotionEvent.AXIS_VSCROLL)
                if (v > 0f) svc.onExtra(Mouse.WHEEL_UP, true)
                else if (v < 0f) svc.onExtra(Mouse.WHEEL_DOWN, true)
            }
        }
        return true
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK && e.actionMasked == MotionEvent.ACTION_MOVE) {
            fun dz(v: Float) = if (abs(v) < 0.15f) 0f else v
            svc.onLeftStick(dz(e.getAxisValue(MotionEvent.AXIS_X)), dz(e.getAxisValue(MotionEvent.AXIS_Y)))
            val rx = e.getAxisValue(MotionEvent.AXIS_Z).let { if (abs(it) > 0.01f) it else e.getAxisValue(MotionEvent.AXIS_RX) }
            val ry = e.getAxisValue(MotionEvent.AXIS_RZ).let { if (abs(it) > 0.01f) it else e.getAxisValue(MotionEvent.AXIS_RY) }
            svc.onRightStick(dz(rx), dz(ry))
            val r = maxOf(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS)) > 0.5f
            val l = maxOf(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE)) > 0.5f
            if (r != rt) { rt = r; svc.onFire(r) }
            if (l != lt) { lt = l; svc.onAim(l) }
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    override fun onDetachedFromWindow() {
        releasePointerCapture()
        super.onDetachedFromWindow()
    }
}
