package com.kbmouse.gamepad

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper

/** Держит несколько "пальцев" одновременно: цепочка коротких жестов с продолжением штрихов. */
class TouchEngine(private val svc: AccessibilityService) {
    private class P(var x: Float, var y: Float) {
        var wx = x
        var wy = y
        var stroke: GestureDescription.StrokeDescription? = null
        var releasing = false
    }

    private val pts = LinkedHashMap<String, P>()
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private val tickMs = 30L

    fun down(id: String, x: Float, y: Float) { pts[id] = P(x, y); kick() }
    fun move(id: String, x: Float, y: Float) { pts[id]?.let { it.wx = x; it.wy = y } }
    fun up(id: String) { pts[id]?.releasing = true; kick() }
    fun clear() { for (p in pts.values) p.releasing = true }

    private fun kick() { if (!running) { running = true; tick() } }

    private fun tick() {
        if (pts.isEmpty()) { running = false; return }
        val b = GestureDescription.Builder()
        val done = ArrayList<String>()
        var n = 0
        for ((id, p) in pts) {
            if (n >= 9) break
            val first = p.stroke == null
            val last = p.releasing && !first
            val path = Path()
            path.moveTo(p.x, p.y)
            if (p.wx != p.x || p.wy != p.y) path.lineTo(p.wx, p.wy)
            val s = if (first) GestureDescription.StrokeDescription(path, 0, tickMs, !last)
            else p.stroke!!.continueStroke(path, 0, tickMs, !last)
            p.stroke = s
            p.x = p.wx; p.y = p.wy
            b.addStroke(s)
            if (last) done.add(id)
            n++
        }
        for (id in done) pts.remove(id)
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { handler.post { tick() } }
            override fun onCancelled(g: GestureDescription?) {
                for (p in pts.values) p.stroke = null
                handler.post { tick() }
            }
        }
        val ok = try { svc.dispatchGesture(b.build(), cb, null) } catch (e: Exception) { false }
        if (!ok) handler.postDelayed({ tick() }, 60)
    }
}
