package com.kbmouse.gamepad

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

/** Оверлей поверх игры: перетаскивай кружки туда, где в игре находятся нужные кнопки. */
class Editor(
    private val svc: MapperService,
    private val wm: WindowManager,
    private val layout: Layout,
    private val size: Pair<Int, Int>,
    private val onClosed: () -> Unit
) {
    private val ctx: Context = svc
    private val dp = ctx.resources.displayMetrics.density
    private val d = (68 * dp).toInt()
    private val root = FrameLayout(ctx)
    private val hint = TextView(ctx)
    private val bar2 = LinearLayout(ctx)

    private class M(val v: TextView, val onPlace: (Float, Float) -> Unit, val key: KeyBind?)

    private val ms = mutableListOf<M>()
    private var waiting = false
    private var deleting = false
    private var pendCode = 0
    private val modeNames = arrayOf("удержание", "переключатель", "авто-нажатие")

    init {
        root.setBackgroundColor(0x99000000.toInt())
        addMarker("Джойстик\nWASD", Color.parseColor("#2E7D32"), layout.joyX, layout.joyY, null) { x, y -> layout.joyX = x; layout.joyY = y }
        addMarker("Камера\n(мышь)", Color.parseColor("#1565C0"), layout.lookX, layout.lookY, null) { x, y -> layout.lookX = x; layout.lookY = y }
        addMarker("Огонь\nЛКМ", Color.parseColor("#C62828"), layout.fireX, layout.fireY, null) { x, y -> layout.fireX = x; layout.fireY = y }
        addMarker("Прицел\nПКМ", Color.parseColor("#6A1B9A"), layout.aimX, layout.aimY, null) { x, y -> layout.aimX = x; layout.aimY = y }
        for (k in layout.keys) addKeyMarker(k)

        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.VERTICAL

        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER
        bar.setBackgroundColor(0xCC222222.toInt())
        bar.addView(btn("Готово") { close(true) })
        bar.addView(btn("+ Клавиша") { waiting = true; pendCode = 0; hint.text = "Нажми клавишу (или Ctrl/Shift/Alt + клавишу для комбо)…" })
        bar.addView(btn("+ Мышь") { bar2.visibility = if (bar2.visibility == View.VISIBLE) View.GONE else View.VISIBLE })
        bar.addView(btn("Удалить: выкл") { b ->
            deleting = !deleting
            b.text = if (deleting) "Удалить: ВКЛ" else "Удалить: выкл"
            hint.text = if (deleting) "Тапни по кружку клавиши, чтобы удалить" else ""
        })
        bar.addView(btn("Сброс") { layout.resetAll(); close(false); svc.startEditor() })
        top.addView(bar)

        bar2.orientation = LinearLayout.HORIZONTAL
        bar2.gravity = Gravity.CENTER
        bar2.setBackgroundColor(0xCC333333.toInt())
        bar2.visibility = View.GONE
        for (c in intArrayOf(Mouse.WHEEL_UP, Mouse.WHEEL_DOWN, Mouse.MIDDLE, Mouse.BACK, Mouse.FWD)) {
            bar2.addView(btn(Mouse.name(c)) { addBind(c, 0) })
        }
        top.addView(bar2)
        root.addView(top, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        hint.setTextColor(Color.WHITE)
        hint.textSize = 14f
        hint.text = "Перетаскивай кружки. Долгое нажатие на кружок клавиши — режим: удержание / переключатель / авто-нажатие"
        val hp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        hp.topMargin = (112 * dp).toInt()
        root.addView(hint, hp)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(root, lp)
    }

    private fun btn(text: String, click: (Button) -> Unit): Button {
        val b = Button(ctx)
        b.text = text
        b.textSize = 11f
        b.setOnClickListener { click(b) }
        return b
    }

    private fun addKeyMarker(k: KeyBind) {
        addMarker(bindLabel(k), Color.parseColor("#EF6C00"), k.x, k.y, k) { x, y -> k.x = x; k.y = y }
    }

    private fun addMarker(label: String, color: Int, fx: Float, fy: Float, key: KeyBind?, onPlace: (Float, Float) -> Unit) {
        val tv = TextView(ctx)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 11f
        tv.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(color)
        bg.setStroke((2 * dp).toInt(), Color.WHITE)
        tv.background = bg
        root.addView(tv, FrameLayout.LayoutParams(d, d))
        tv.x = fx * size.first - d / 2f
        tv.y = fy * size.second - d / 2f
        val m = M(tv, onPlace, key)
        ms.add(m)

        var dX = 0f
        var dY = 0f
        var sX = 0f
        var sY = 0f
        var moved = false
        var longDone = false
        val longRun = Runnable {
            if (key != null && !moved) {
                key.mode = (key.mode + 1) % 3
                tv.text = bindLabel(key)
                hint.text = "Режим: " + modeNames[key.mode]
                longDone = true
            }
        }
        tv.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dX = v.x - ev.rawX; dY = v.y - ev.rawY
                    sX = ev.rawX; sY = ev.rawY
                    moved = false; longDone = false
                    root.postDelayed(longRun, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && hypot(ev.rawX - sX, ev.rawY - sY) > 12 * dp) { moved = true; root.removeCallbacks(longRun) }
                    if (moved) { v.x = ev.rawX + dX; v.y = ev.rawY + dY }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    root.removeCallbacks(longRun)
                    if (ev.actionMasked == MotionEvent.ACTION_UP && !moved && !longDone && deleting && m.key != null) {
                        layout.keys.remove(m.key)
                        ms.remove(m)
                        root.removeView(v)
                    }
                }
            }
            true
        }
    }

    private fun addBind(code: Int, mods: Int) {
        val reserved = (mods == 0 && (code == KeyEvent.KEYCODE_W || code == KeyEvent.KEYCODE_A ||
            code == KeyEvent.KEYCODE_S || code == KeyEvent.KEYCODE_D)) ||
            code == MapperService.KEY_TOGGLE || code == MapperService.KEY_FREE
        if (reserved || layout.keys.any { it.keyCode == code && it.mods == mods }) {
            hint.text = "Эта клавиша занята, выбери другую"
            return
        }
        val k = KeyBind(code, 0.5f, 0.5f, MODE_HOLD, mods)
        layout.keys.add(k)
        addKeyMarker(k)
        waiting = false
        pendCode = 0
        hint.text = "Добавлено — перетащи кружок на нужное место"
    }

    private fun isModKey(c: Int) = c == KeyEvent.KEYCODE_CTRL_LEFT || c == KeyEvent.KEYCODE_CTRL_RIGHT ||
        c == KeyEvent.KEYCODE_SHIFT_LEFT || c == KeyEvent.KEYCODE_SHIFT_RIGHT ||
        c == KeyEvent.KEYCODE_ALT_LEFT || c == KeyEvent.KEYCODE_ALT_RIGHT

    fun onKey(e: KeyEvent): Boolean {
        if (!waiting) return false
        val c = e.keyCode
        val mod = isModKey(c)
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
            if (mod) {
                pendCode = c
                hint.text = "Нажми вторую клавишу для комбо или отпусти эту, чтобы добавить её саму"
            } else {
                val mods = modsOf(e)
                addBind(c, mods)
            }
        } else if (e.action == KeyEvent.ACTION_UP && mod && c == pendCode) {
            addBind(c, 0)
        }
        return true
    }

    fun close(save: Boolean) {
        if (save) {
            for (m in ms) m.onPlace((m.v.x + d / 2f) / size.first, (m.v.y + d / 2f) / size.second)
        }
        try { wm.removeView(root) } catch (e: Exception) { }
        onClosed()
    }
}
